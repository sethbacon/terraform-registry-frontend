# e2e-upload-fixture

Minimal fixture module used by Playwright E2E tests to exercise the real
module upload flow (frontend -> backend -> storage), not a usable module.
