# Minimal placeholder module for E2E upload-flow testing.
# Not a real infrastructure module -- exercises the upload pipeline only.
variable "name" {
  type        = string
  description = "Placeholder name variable."
}

output "name" {
  value = var.name
}
